package model;

public class EnumDirection {
	public enum Direction{
		NONE,
		UP,
		DOWN,
		LEFT,
		RIGHT
	}
}
